<title>IPL Payment - 
	<?php if($_SERVER['SCRIPT_NAME']=="/ipl/admin/index.php") { ?>
		Admin Dashboard
	<?php }else if($_SERVER['SCRIPT_NAME']=="/ipl/admin/rumah.php") { ?>
		Daftar Rumah
	<?php }else if($_SERVER['SCRIPT_NAME']=="/ipl/admin/rumah_tambah.php") { ?>
		Tambah Data Rumah
	<?php }else if($_SERVER['SCRIPT_NAME']=="/ipl/admin/rumah_edit.php") { ?>
		Ubah Data Rumah
	<?php }else if($_SERVER['SCRIPT_NAME']=="/ipl/admin/user.php") { ?>
		Daftar User
	<?php }else if($_SERVER['SCRIPT_NAME']=="/ipl/admin/user_tambah.php") { ?>
		Tambah Data User
	<?php }else if($_SERVER['SCRIPT_NAME']=="/ipl/admin/user_edit.php") { ?>
		Edit Data User
	<?php }else if($_SERVER['SCRIPT_NAME']=="/ipl/admin/user_detail.php") { ?>
		Detail User
	<?php }else if($_SERVER['SCRIPT_NAME']=="/ipl/admin/tarif.php") { ?>
		Ubah Tarif
	<?php }else if($_SERVER['SCRIPT_NAME']=="/ipl/admin/tagihan.php") { ?>
		Tagihan
	<?php }else if($_SERVER['SCRIPT_NAME']=="/ipl/admin/input_penggunaan.php") { ?>
		Input Penggunaan
	<?php }else if($_SERVER['SCRIPT_NAME']=="/ipl/admin/tagihan_detail.php") { ?>
		Detail Tagihan
	<?php }else if($_SERVER['SCRIPT_NAME']=="/ipl/admin/tagihan_approve.php") { ?>
		Approve Tagihan
	<?php }else if($_SERVER['SCRIPT_NAME']=="/ipl/admin/broadcast.php") { ?>
		Broadcast Message
	<?php }else if($_SERVER['SCRIPT_NAME']=="/ipl/admin/login.php") { ?>
		Admin Login
	<?php }else if($_SERVER['SCRIPT_NAME']=="/ipl/login.php") { ?>
		Login
	<?php }else if($_SERVER['SCRIPT_NAME']=="/ipl/index.php") { ?>
		Dashboard
	<?php }else if($_SERVER['SCRIPT_NAME']=="/ipl/riwayat.php") { ?>
		Riwayat Pembayaran
	<?php }else if($_SERVER['SCRIPT_NAME']=="/ipl/bayar.php") { ?>
		Pembayaran
	<?php }else if($_SERVER['SCRIPT_NAME']=="/ipl/tagihan_detail.php") { ?>
		Detail Tagihan
	<?php }else if($_SERVER['SCRIPT_NAME']=="/ipl/profil.php") { ?>
		Profil User
	<?php }else if($_SERVER['SCRIPT_NAME']=="/ipl/kotakmasuk.php") { ?>
		Kotak Masuk
	<?php }else {?>
		Undefined
	<?php } ?>
</title>